,# hello-world
just another repository

This is the first time I use github, try to learn more.
I hope it will be a good journey.

Thank you very much.
Have a good time.

Add, try to use git in the linux system.
